﻿using System;

public class Program
{
    public static void Main()
    {
        string s = Console.ReadLine();
        string[] arr = s.Split();
        int a = int.Parse(arr[0]);
        int b = int.Parse(arr[1]);
        Console.WriteLine(a * b);
    }
}